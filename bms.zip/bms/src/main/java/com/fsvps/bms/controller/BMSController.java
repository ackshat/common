package com.fsvps.bms.controller;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

import com.fsvps.bms.service.BMSService;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.theme.ThemeDisplay;

@Controller
@RequestMapping("VIEW")
public class BMSController {
	
	
	private BMSService bmsService;

    public BMSService getBmsService() {
		return bmsService;
	}

	public void setBmsService(BMSService bmsService) {
		this.bmsService = bmsService;
	}

	@RenderMapping
    public String showHome(RenderRequest request, RenderResponse response) throws Exception {
    	ThemeDisplay td  =(ThemeDisplay)request.getAttribute(WebKeys.THEME_DISPLAY);
    	User user = td.getUser();
    	bmsService.getAssignedIssues(user.getUserId());
    	return "bms-home";
	}
}