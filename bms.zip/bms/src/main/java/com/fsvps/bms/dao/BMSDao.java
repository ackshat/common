package com.fsvps.bms.dao;

import java.util.List;

import com.fsvps.bms.domain.Bug;
import com.fsvps.bms.domain.Comment;

public interface BMSDao {

	
	public List<Bug> getAssignedIssues(Long userId);
	

	public List<Bug> getReportedBugs(Long userId);
	

	public List<Bug> getIssues(Long projectId, Long userId, String status);
	

	public List<Bug> getIssues(Long projectId, String status);
	

	public List<Bug> getIssues(String status);
	

	public List<Bug> getIssues(Long projectId);
	
	public List<Comment> getCommentsForIssue(Long bugId);
	

	
}
