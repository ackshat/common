package com.fsvps.bms.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.fsvps.bms.domain.Bug;
import com.fsvps.bms.domain.Comment;

public class BMSDaoImpl  extends SqlMapClientDaoSupport implements BMSDao{

	public BMSDaoImpl(){
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Bug> getAssignedIssues(Long userId) {
		return getSqlMapClientTemplate().queryForList("getAssignedBugs", userId);
	}

	@Override
	public List<Bug> getReportedBugs(Long userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bug> getIssues(Long projectId, Long userId, String status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bug> getIssues(Long projectId, String status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bug> getIssues(String status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bug> getIssues(Long projectId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Comment> getCommentsForIssue(Long bugId) {
		// TODO Auto-generated method stub
		return null;
	}

}
