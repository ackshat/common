package com.fsvps.bms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsvps.bms.dao.BMSDao;
import com.fsvps.bms.dao.BMSDaoImpl;
import com.fsvps.bms.domain.Bug;
import com.fsvps.bms.domain.Comment;


public class BMSServiceImpl implements BMSService {

	public BMSServiceImpl() {
	}
	
	@Autowired
	private BMSDao bmsDao;

	
	
	public BMSDao getBmsDao() {
		return bmsDao;
	}

	public void setBmsDao(BMSDao bmsDao) {
		this.bmsDao = bmsDao;
	}

	@Override
	public List<Bug> getAssignedIssues(Long userId) {
		return bmsDao.getAssignedIssues(userId);
	}

	@Override
	public List<Bug> getReportedBugs(Long userId) {
		return (ArrayList<Bug>)bmsDao.getReportedBugs(userId);
	}

	@Override
	public List<Bug> getIssues(Long projectId, Long userId, String status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bug> getIssues(Long projectId, String status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bug> getIssues(String status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bug> getIssues(Long projectId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Comment> getCommentsForIssue(Long bugId) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
