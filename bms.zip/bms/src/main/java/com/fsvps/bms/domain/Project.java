package com.fsvps.bms.domain;

public class Project {

}
