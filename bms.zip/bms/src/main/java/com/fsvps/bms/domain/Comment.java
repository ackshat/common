package com.fsvps.bms.domain;

import java.util.Date;

public class Comment {

	
	private Long nbcommentId;
	private Long nbsequence;
	private String vcdescription;
	private Date dtdate;
	private boolean bldeleted;
	private Long nbbugId;
	private Long nbuserId;
	public Long getNbcommentId() {
		return nbcommentId;
	}
	public void setNbcommentId(Long nbcommentId) {
		this.nbcommentId = nbcommentId;
	}
	public Long getNbsequence() {
		return nbsequence;
	}
	public void setNbsequence(Long nbsequence) {
		this.nbsequence = nbsequence;
	}
	public String getVcdescription() {
		return vcdescription;
	}
	public void setVcdescription(String vcdescription) {
		this.vcdescription = vcdescription;
	}
	public Date getDtdate() {
		return dtdate;
	}
	public void setDtdate(Date dtdate) {
		this.dtdate = dtdate;
	}
	public boolean isBldeleted() {
		return bldeleted;
	}
	public void setBldeleted(boolean bldeleted) {
		this.bldeleted = bldeleted;
	}
	public Long getNbbugId() {
		return nbbugId;
	}
	public void setNbbugId(Long nbbugId) {
		this.nbbugId = nbbugId;
	}
	public Long getNbuserId() {
		return nbuserId;
	}
	public void setNbuserId(Long nbuserId) {
		this.nbuserId = nbuserId;
	}
	
	
}
