package chapter03.code.listing.utils;

public class Constants {
	public static final String MANNING = "Manning";
	public static final String JETSPEED = "Jetspeed";
	public static final String LIFERAY = "Liferay";
	public static final String GLASSFISH = "Glassfish";
}
