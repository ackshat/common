function confirmRemove() {
	return confirm("Do you want to delete the selected book ?");
}